import React from 'react';

const Home = () => {
  return (
    <div className="container mt-4">
      <h1>Welcome to My React App</h1>
      <p>This is a simple React app with Bootstrap 5.</p>
    </div>
  );
};

export default Home;
